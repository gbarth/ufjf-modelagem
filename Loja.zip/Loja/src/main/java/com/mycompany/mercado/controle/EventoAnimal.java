package com.mycompany.mercado.controle;

import com.mycompany.mercado.mercadoClasses.Animal;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import com.mycompany.mercado.telas.cadastroAnimal;


public class EventoAnimal implements WindowListener {

  cadastroAnimal cadastroA = null;

  public EventoAnimal(cadastroAnimal tela) {
    this.cadastroA = tela;
  }

  @Override
  public void windowOpened(WindowEvent e) {
    
    try {
      if(Animal.listaAnimal.size() > 0){
        for(int i = 0; i < Animal.listaAnimal.size(); i++){
          if(Animal.listaAnimal.get(i).getRaca().length() > 0){
            String animal =  Animal.listaAnimal.get(i).getAnimal();
            String idade = Animal.listaAnimal.get(i).getAnimal();
            String sexo = Animal.listaAnimal.get(i).getAnimal();
            String data = Animal.listaAnimal.get(i).getAnimal();
            String caract = Animal.listaAnimal.get(i).getAnimal();
            String raca = Animal.listaAnimal.get(i).getAnimal();
            
                DefaultTableModel val = (DefaultTableModel) cadastroA.tableAnimal.getModel();
                val.addRow(new String[]{animal, raca, idade, data, sexo, caract});
            }
        }   
      } 

        cadastroA.repaint();
    } catch (Exception ex) {
      System.err.println("erro: " + ex);
    }
    
    
  }

  @Override
  public void windowClosing(WindowEvent e) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void windowClosed(WindowEvent e) {
    // TODO Auto-generated method stub

  }

  @Override
  public void windowIconified(WindowEvent e) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void windowDeiconified(WindowEvent e) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void windowActivated(WindowEvent e) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void windowDeactivated(WindowEvent e) {
    // TODO Auto-generated method stub
    
  }
  
}
