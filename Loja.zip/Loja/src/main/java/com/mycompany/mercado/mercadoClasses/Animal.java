package com.mycompany.mercado.mercadoClasses;

import java.util.ArrayList;
import java.util.List;

public class Animal {

    private String animal;
    private String raca;
    private String idade;
    private String sexo;
    private String dataEntrada;
    private String caract;
    
    public static List<Animal> listaAnimal = new ArrayList<>();

    public Animal() {

    }

    public Animal(String animal, String raca, String idade, String sexo, String dataEntrada, String caracteristicas) {
        this.animal = animal;
        this.raca = raca;
        this.idade = idade;
        this.sexo = sexo;
        this.dataEntrada = dataEntrada;
        this.caract = caracteristicas;
    }
    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(String dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public String getCaracteristicas() {
        return caract;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caract = caracteristicas;
    }
}
